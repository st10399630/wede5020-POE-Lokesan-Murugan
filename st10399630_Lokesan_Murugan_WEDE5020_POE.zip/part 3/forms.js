//function to validate the form!
//the event funtion is what allows user input interactions!

function validateForm (event){
    event.preventDefault();
    //this does not allow the form to be entered without data input



//fetch data from the inputs on the form

var name = document.getElementById('name'). value; 
var email = document.getElementById('email'). value;


//Clearing previous errors
document.getElementById('nameError').textContent = '';
document.getElementById('emailError').textContent = '';



//Validating name field
if( name === ''){
    document.getElementById('nameError').textContent = 'Please enter your Name';
    return;

}
//validating email field
if (email === ''){
    document.getElementById('emailError').textContent = 'Please enter your Email';
    return;
}

//Display success message
alert('Thank you, the Form has been submitted successfully!');

}
var form = document.getElementById('regForm');
form.addEventListener('submit', validateForm);
